import React, { useState, useEffect } from "react";
import { Redirect, withRouter } from 'react-router-dom';
import { Container, Row, Col } from 'react-bootstrap'
import axios from 'axios';
import { Auth } from 'aws-amplify';

import SlidingPane from "react-sliding-pane";
import "react-sliding-pane/dist/react-sliding-pane.css";


import Navbar from './components/navbar'
import Searchbar from './components/searchbar'
import SearchFilters from './components/search-filters'
import SingleStat from './components/single-stat'
import SectionTitle from './components/section-title'
import PrismPieChart from './components/pie-chart'
import PrismLineChart from './components/line-chart'
import PrismBarChart from './components/bar-chart'
import PrismSunburst from './components/sunburst-chart'
import PrismScatterplot from './components/scatterplot'
import PrismChoropleth from './components/choropleth'

import './index.css'

const initialStats = [
  {
    color: 'red',
    stats: [
      { title: 'Trials', metric: '--' },
      { title: 'Sites', metric: '--' },
      { title: 'Participants', metric: '--' }
    ]
  },
  {
    color: 'orange',
    stats: [
      { title: 'Technologies', metric: '--' },
      { title: 'Interventions', metric: '--' }
    ]
  },
  {
    color: 'green',
    stats: [
      { title: 'Outcomes', metric: '--' }
    ]
  },
  {
    color: 'blue',
    stats: [
      { title: 'Manufacturers', metric: '--' }
    ]
  },
  {
    color: 'indigo',
    stats: [
      { title: 'Sponsors', metric: '--' }
    ]
  },
  {
    color: 'violet',
    stats: [
      { title: 'Publications', metric:'--' }
    ]
  }
]

const initialTrialFilters = {
  Status: {},
  Purpose: {},
  Type: {}
}

const initialTechnologyFilters = {
  Components: {},
  'Body Location': {}
}

const initialConditionsFilters = {
  Conditions: {}
}

const initialMeasuresFilters = {
  Measures: {}
}

const initialManufacturersFilters = {
  Manufacturers: {}
}

const initialSponsorsFilters = {
  Sponsors: {}
}

const initialGeographyFilters = {
  Geography: {}
}

function DashboardRoute(props) {

  const [currentUser, setCurrentUser] = useState("")

  useEffect((props) => {
    const getCurrentAuthenticatedUser = async () => {
      try {
        const user = await Auth.currentAuthenticatedUser()
        setCurrentUser(user)
      } catch (error) {
        setCurrentUser(undefined)
      }
    }
    getCurrentAuthenticatedUser()
  }, [currentUser])


  const [updateRequested, setUpdatedRequested] = useState("")
  const onUpdateButtonClicked = (e) => {
    setUpdatedRequested(Date())
    closeSidebar()
  }

  const [trialsFilters, setTrialsFilters] = useState(initialTrialFilters)
  const [technologyFilters, setTechnologyFilters] = useState(initialTechnologyFilters)
  const [conditionsFilters, setConditionsFilters] = useState(initialConditionsFilters)
  const [measuresFilters, setMeasuresFilters] = useState(initialMeasuresFilters)
  const [manufacturersFilters, setManufacturersFilters] = useState(initialManufacturersFilters)
  const [sponsorsFilters, setSponsorsFilters] = useState(initialSponsorsFilters)
  const [geographyFilters, setGeographyFilters] = useState(initialGeographyFilters)
  const [initialFilterLoadComplete, setInitialFilterLoadComplete] = useState(false)
  const fetchFilters = async () => {
    const result = await axios.get('https://7x2xibe2wl.execute-api.us-east-1.amazonaws.com/filters');
    setTrialsFilters(result.data.trials)
    setTechnologyFilters(result.data.technologies)
    setConditionsFilters(result.data.conditions)
    setMeasuresFilters(result.data.measures)
    setManufacturersFilters(result.data.manufacturers)
    setSponsorsFilters(result.data.sponsors)
    setGeographyFilters(result.data.geography)
    setInitialFilterLoadComplete(true)
    // setUpdatedRequested(Date.now())
  }
  useEffect(() => {
    fetchFilters();
  }, [])

  const generateFiltersPostBody = () => {
    return {
      "Trials": trialsFilters,
      "Technology": technologyFilters,
      "Conditions": conditionsFilters,
      "Measures": measuresFilters,
      "Manufacturers": manufacturersFilters,
      "Sponsors": sponsorsFilters,
      "Geography": geographyFilters,
    }
  }

  const [sidebarIsVisible, setSidebarIsVisible] = useState(false)
  const [activeCategoryFilter, setActiveCategoryFilter] = useState("")
  const [activeParentFilter, setActiveParentFilter] = useState("")
  const [activeParentFilterSections, setActiveParentFilterSections] = useState({})
  const [hoveredParentFilter, setHoveredParentFilter] = useState("")
  const [activeChildFilterSections, setActiveChildFilterSections] = useState({})

  const [stats, setStats] = useState(initialStats)

  const [trialStatusPieChartData, setTrialStatusPieChartData] = useState([])
  const [trialPurposePieChartData, setTrialPurposePieChartData] = useState([])
  const [trialTypePieChartData, setTrialTypePieChartData] = useState([])
  const [trialAgeGroupsPieChartData, setTrialAgeGroupsPieChartData] = useState([])
  const [cumulativeTrialsLineChartData, setCumulativeTrialsLineChartData] = useState([])

  const [landscapeChartData, setLandscapeChartData] = useState([])

  const [technologyComponentsPieChartData, setTechnologyComponentsPieChartData] = useState([])
  const [bodyLocationsComponentsPieChartData, setBodyLocationsComponentsPieChartData] = useState([])
  const [top10TechnologiesAsInterventionBarChartData, setTop10TechnologiesAsInterventionBarChartData] = useState({data: [], group_keys: []})
  const [top10TechnologiesAsOutcomesBarChartData, setTop10TechnologiesAsOutcomesBarChartData] = useState({data: [], group_keys: []})
  const [newTechnologiesPerYearBarChartData, setNewTechnologiesPerYearBarChartData] = useState({data: [], group_keys: []})

  const [conditionsTop10ParentBarChartData, setConditionsTop10ParentBarChartData] = useState({data: [], group_keys: []})
  const [conditionsTop10ChildBarChartData, setConditionsTop10ChildBarChartData] = useState({data: [], group_keys: []})
  const [conditionsBreakdownSunburstChartData, setConditionsBreakdownSunburstChartData] = useState([])

  const [measuresTop10BarChartData, setMeasuresTop10BarChartData] = useState({data: [], group_keys: []})
  const [measuresOverTimeLineChart, setMeasuresOverTimeLineChart] = useState([])

  const [manufacturersTop10ByTrialsBarChartData, setManufacturersTop10ByTrialsBarChartData] = useState({data: [], group_keys: []})
  const [manufacturersTop10ByProductsBarChartData, setManufacturersTop10ByProductsBarChartData] = useState({data: [], group_keys: []})

  const [sponsorsTop10ByTrialsBarChartData, setSponsorsTop10ByTrialsBarChartData] = useState({data: [], group_keys: []})
  const [sponsorsTop10ByEnrollmentBarChartData, setSponsorsTop10ByEnrollmentBarChartData] = useState({data: [], group_keys: []})
  const [sponsorsBreakdownChartData, setSponsorsBreakdownChartData] = useState([])

  const [geographyFacilitiesChartData, setGeographyFacilitiesChartData] = useState([])

  const [loadingStatsData, setLoadingStatsData] = useState(true)
  const [loadingTrialsData, setLoadingTrialsData] = useState(true)
  const [loadingLandscapeData, setLoadingLandscapeData] = useState(true)
  const [loadingTechnologyData, setLoadingTechnologyData] = useState(true)
  const [loadingConditionsData, setLoadingConditionsData] = useState(true)
  const [loadingMeasuresData, setLoadingMeasuresData] = useState(true)
  const [loadingManufacturersData, setLoadingManufacturersData] = useState(true)
  const [loadingSponsorsData, setLoadingSponsorsData] = useState(true)
  const [loadingGeographyData, setLoadingGeographyData] = useState(true)

  const fetchSingleStatMetrics = async () => {
    const result = await axios.post(
      'https://7x2xibe2wl.execute-api.us-east-1.amazonaws.com/metrics',
      {
        filters: generateFiltersPostBody()
      },
      {
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );

    setStats([
      {
        color: 'red',
        stats: [
          { title: 'Trials', metric: result.data.trials_count },
          { title: 'Sites', metric: result.data.sites_count },
          { title: 'Participants', metric: result.data.participants_sum }
        ]
      },
      {
        color: 'orange',
        stats: [
          { title: 'Technologies', metric: result.data.technologies_count },
          { title: 'Interventions', metric: result.data.interventions_count }
        ]
      },
      {
        color: 'green',
        stats: [
          { title: 'Outcomes', metric: result.data.outcomes_count }
        ]
      },
      {
        color: 'blue',
        stats: [
          { title: 'Manufacturers', metric: result.data.manufacturers_count }
        ]
      },
      {
        color: 'indigo',
        stats: [
          { title: 'Sponsors', metric: result.data.sponsors_count }
        ]
      },
      {
        color: 'violet',
        stats: [
          { title: 'Publications', metric: result.data.publications_count }
        ]
      }
    ])
    setLoadingStatsData(false)
  }

  const fetchTrialsMetricData = async () => {
    const result = await axios.post(
      'https://7x2xibe2wl.execute-api.us-east-1.amazonaws.com/metrics/trials',
      {
        filters: generateFiltersPostBody()
      },
      {
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );

    setTrialStatusPieChartData(result.data.trials_status_pie);
    setTrialPurposePieChartData(result.data.trials_purpose_pie);
    setTrialTypePieChartData(result.data.trials_type_pie);
    setTrialAgeGroupsPieChartData(result.data.trials_age_groups_pie);
    setCumulativeTrialsLineChartData(result.data.trials_cumulative_over_time_line);

    setLoadingTrialsData(false)
  }

  const fetchLandscapeChartData = async () => {
    const result = await axios.post(
      'https://7x2xibe2wl.execute-api.us-east-1.amazonaws.com/metrics/landscape',
      {
        filters: generateFiltersPostBody(),
        x_axis: '',
        y_axis: '',
      },
      {
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );

    setLandscapeChartData(result.data);
    setLoadingLandscapeData(false)
  }

  const fetchTechnologyMetricData = async () => {
    const result = await axios.post(
      'https://7x2xibe2wl.execute-api.us-east-1.amazonaws.com/metrics/technology',
      {
        filters: generateFiltersPostBody()
      },
      {
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );

    setTechnologyComponentsPieChartData(result.data.technologies_components_pie);
    setBodyLocationsComponentsPieChartData(result.data.technologies_body_locations_pie);
    setTop10TechnologiesAsInterventionBarChartData(result.data.technologies_top_10_as_intervention_bar)
    setTop10TechnologiesAsOutcomesBarChartData(result.data.technologies_top_10_as_outcomes_bar)
    setNewTechnologiesPerYearBarChartData(result.data.technologies_new_technologies_per_year_bar)

    setLoadingTechnologyData(false)
  }

  const fetchConditionsMetricData = async () => {
    const result = await axios.post(
      'https://7x2xibe2wl.execute-api.us-east-1.amazonaws.com/metrics/conditions',
      {
        filters: generateFiltersPostBody()
      },
      {
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );

    setConditionsTop10ParentBarChartData(result.data.conditions_top_10_parents_bar);
    setConditionsTop10ChildBarChartData(result.data.conditions_top_10_children_bar);
    setConditionsBreakdownSunburstChartData(result.data.conditions_breakdown_sunburst)

    setLoadingConditionsData(false)
  }

  const fetchMeasuresMetricData = async () => {
    const result = await axios.post(
      'https://7x2xibe2wl.execute-api.us-east-1.amazonaws.com/metrics/measures',
      {
        filters: generateFiltersPostBody()
      },
      {
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );

    setMeasuresTop10BarChartData(result.data.measures_top_10_measures_bar);
    setMeasuresOverTimeLineChart(result.data.measures_over_time_line);

    setLoadingMeasuresData(false)
  }

  const fetchManufacturersData = async () => {
    const result = await axios.post(
      'https://7x2xibe2wl.execute-api.us-east-1.amazonaws.com/metrics/manufacturers',
      {
        filters: generateFiltersPostBody()
      },
      {
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );

    setManufacturersTop10ByTrialsBarChartData(result.data.manufacturers_top_10_by_trials);
    setManufacturersTop10ByProductsBarChartData(result.data.manufacturers_top_10_by_products);

    setLoadingManufacturersData(false)
  }

  const fetchSponsorsData = async () => {
        const result = await axios.post(
          'https://7x2xibe2wl.execute-api.us-east-1.amazonaws.com/metrics/sponsors',
          {
            filters: generateFiltersPostBody()
          },
          {
            headers: {
              'Content-Type': 'application/json'
            }
          }
        );

        setSponsorsTop10ByTrialsBarChartData(result.data.sponsors_top_10_by_trials);
        setSponsorsTop10ByEnrollmentBarChartData(result.data.sponsors_top_10_by_enrollment);
        setSponsorsBreakdownChartData(result.data.sponsors_breakdown);

        setLoadingSponsorsData(false)
      }

  const fetchGeographyData = async () => {
    const result = await axios.post(
      'https://7x2xibe2wl.execute-api.us-east-1.amazonaws.com/metrics/geography',
      {
        filters: generateFiltersPostBody()
      },
      {
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );

    setGeographyFacilitiesChartData(result.data.facilities_geography);

    setLoadingGeographyData(false)
  }

  useEffect(() => {
    if (initialFilterLoadComplete) {
      setLoadingStatsData(true)
      fetchSingleStatMetrics();
      setLoadingTrialsData(true)
      fetchTrialsMetricData();
      setLoadingLandscapeData(true)
      fetchLandscapeChartData();
      setLoadingTechnologyData(true)
      fetchTechnologyMetricData();
      setLoadingConditionsData(true)
      fetchConditionsMetricData();
      setLoadingMeasuresData(true)
      fetchMeasuresMetricData();
      setLoadingManufacturersData(true)
      fetchManufacturersData();
      setLoadingSponsorsData(true)
      fetchSponsorsData();
      setLoadingGeographyData(true)
      fetchGeographyData();
    }
    // eslint-disable-next-line
  }, [updateRequested, initialFilterLoadComplete])

  if (currentUser === undefined) {
    return <Redirect to="/login" />
  }

  const closeSidebar = () => {
    setSidebarIsVisible(false)
    setActiveCategoryFilter("")
    setActiveParentFilterSections({})
  }

  const onFilterHover = (filter) => {
    setHoveredParentFilter(filter)
    if (!activeParentFilter) {
      switch (activeCategoryFilter) {
        case 'Conditions':
          setActiveChildFilterSections({[filter]: conditionsFilters['Children'][filter]})
          break;
        case 'Sponsors':
          setActiveChildFilterSections({[filter]: sponsorsFilters['Children'][filter]})
          break;
        case 'Geography':
          setActiveChildFilterSections({[filter]: geographyFilters['Children'][filter]})
          break;
        default:
          setActiveChildFilterSections({})
          break;
      }
    }
  }

  const onFilterUnHover = (filter) => {
    setHoveredParentFilter(null)
    if (!activeParentFilter) {
      setActiveChildFilterSections({})
    }
  }

  const onNavItemClicked = (e, title) => {
    e.preventDefault()

    if (title === activeCategoryFilter) {
      setSidebarIsVisible(false)
      setActiveCategoryFilter("")
      setActiveParentFilterSections({})
      setActiveParentFilter("")
    }
    else {
      setSidebarIsVisible(true)
      setActiveCategoryFilter(title)
      setActiveParentFilter("")
      switch (title) {
        case 'Trials':
          setActiveParentFilterSections(trialsFilters)
          break;
        case 'Technology':
          setActiveParentFilterSections(technologyFilters)
          break;
        case 'Conditions':
          const conditionsParentFilterSections = { ...conditionsFilters};
          delete conditionsParentFilterSections.Children
          setActiveParentFilterSections(conditionsParentFilterSections)
          break;
        case 'Measures':
          setActiveParentFilterSections(measuresFilters)
          break;
        case 'Manufacturers':
          setActiveParentFilterSections(manufacturersFilters)
          break;
        case 'Sponsors':
          const sponsorParentFilterSections = { ...sponsorsFilters};
          delete sponsorParentFilterSections.Children
          setActiveParentFilterSections(sponsorParentFilterSections)
          break;
        case 'Geography':
          const geographyParentFilterSections = { ...geographyFilters};
          delete geographyParentFilterSections.Children
          setActiveParentFilterSections(geographyParentFilterSections)
          break;
        default:
          setActiveParentFilterSections({})
      }
    }
  }

  const updateFilters = (filters, section, filter) => {
    return ({
      ...filters,
      [section]: {
        ...filters[section],
        [filter]: !filters[section][filter]
      }
    })
  }

  const updateChildFilters = (filters, section, filter) => {
    return ({
      ...filters,
      Children: {
        ...updateFilters(filters.Children, section, filter)
      }
    })
  }

  const onParentFilterClicked = (section, filter, shouldSelect=true) => {

    if (filter) {
      switch (activeCategoryFilter) {
        case 'Trials':
          setTrialsFilters(filters => updateFilters(filters, section, filter))
          setActiveParentFilterSections(filters => updateFilters(filters, section, filter))
          if ((filter || trialsFilters[section][filter] === false) && shouldSelect === true){
            setActiveParentFilter(filter)
            setActiveChildFilterSections({})
          }
          break;
        case 'Technology':
          setTechnologyFilters(filters => updateFilters(filters, section, filter))
          setActiveParentFilterSections(filters => updateFilters(filters, section, filter))
          if ((filter || technologyFilters[section][filter] === false) && shouldSelect === true){
            setActiveParentFilter(filter)
            setActiveChildFilterSections({})
          }
          break;
        case 'Conditions':
          setConditionsFilters(filters => updateFilters(filters, section, filter))
          setActiveParentFilterSections(filters => updateFilters(filters, section, filter))
          if ((filter || conditionsFilters[section][filter] === false) && shouldSelect === true){
            setActiveParentFilter(filter)
            setActiveChildFilterSections({[filter]: conditionsFilters['Children'][filter]})
          }
          break;
        case 'Measures':
          setMeasuresFilters(filters => updateFilters(filters, section, filter))
          setActiveParentFilterSections(filters => updateFilters(filters, section, filter))
          if ((filter || measuresFilters[section][filter] === false) && shouldSelect === true){
            setActiveParentFilter(filter)
            setActiveChildFilterSections({})
          }
          break;
        case 'Manufacturers':
          setManufacturersFilters(filters => updateFilters(filters, section, filter))
          setActiveParentFilterSections(filters => updateFilters(filters, section, filter))
          if ((filter || manufacturersFilters[section][filter] === false) && shouldSelect === true){
            setActiveParentFilter(filter)
            setActiveChildFilterSections({})
          }
          break;
        case 'Sponsors':
          setSponsorsFilters(filters => updateFilters(filters, section, filter))
          setActiveParentFilterSections(filters => updateFilters(filters, section, filter))
          if ((filter || sponsorsFilters[section][filter] === false) && shouldSelect === true){
            setActiveParentFilter(filter)
            setActiveChildFilterSections({[filter]: sponsorsFilters['Children'][filter]})
          }
          break;
        case 'Geography':
          setGeographyFilters(filters => updateFilters(filters, section, filter))
          setActiveParentFilterSections(filters => updateFilters(filters, section, filter))
          if ((filter || geographyFilters[section][filter] === false) && shouldSelect === true){
            setActiveParentFilter(filter)
            setActiveChildFilterSections({[filter]: geographyFilters['Children'][filter]})
          }
          break;
        default:
          setActiveParentFilterSections({})
      }
    }
  }

  const onParentFilterLabelClicked = (section, filter) => {
    if (!filter || activeParentFilter === filter){
      setActiveParentFilter(null)
      setActiveChildFilterSections({})
    } else {
      setActiveParentFilter(filter)
      switch (activeCategoryFilter) {
        case 'Conditions':
          setActiveChildFilterSections({[filter]: conditionsFilters['Children'][filter]})
          break;
        case 'Sponsors':
          setActiveChildFilterSections({[filter]: sponsorsFilters['Children'][filter]})
          break;
        case 'Geography':
          setActiveChildFilterSections({[filter]: geographyFilters['Children'][filter]})
          break;
        default:
          setActiveChildFilterSections({})
          break;
      }
    }
  }

  const onChildFilterClicked = (section, filter) => {
    if (filter) {

      switch (activeCategoryFilter) {
        case 'Conditions':
          setConditionsFilters(filters => updateChildFilters(filters, section, filter))
          setActiveChildFilterSections(filters => updateFilters(filters, section, filter))
          break;
        case 'Sponsors':
          setSponsorsFilters(filters => updateChildFilters(filters, section, filter))
          setActiveChildFilterSections(filters => updateFilters(filters, section, filter))
          break;
        case 'Geography':
          setGeographyFilters(filters => updateChildFilters(filters, section, filter))
          setActiveChildFilterSections(filters => updateFilters(filters, section, filter))
          break;
        default:
          break;
      }
    }
  }

  const showDoubleSideBar = (activeParentFilter || hoveredParentFilter) && ['Conditions', 'Sponsors', 'Geography'].includes(activeCategoryFilter)

  const colors = {
    'Trials': 'red',
    'Technology': 'orange',
    'Conditions': 'yellow',
    'Measures': 'green',
    'Manufacturers': 'blue',
    'Sponsors': 'indigo',
    'Geography': 'violet',
  }

  return (
    <div>
      <Navbar
        onNavItemClicked={onNavItemClicked}
        activeTab={activeCategoryFilter}
        onUpdateButtonClicked={onUpdateButtonClicked}
      />

      <Container fluid className='dashboard-route'>

        <div className="full-width">
          <Row className="no-gutters">
            <Col className="searchbar-container">
              <Searchbar />
            </Col>
          </Row>

          <div className="scrollable-container">
              <Row className="d-none d-xl-block" style={{ paddingTop: '80px'}}>
                <Col xl={{span: 12}}>
                  <div className="single-stats-containers">
                    {
                      stats.map((stat, index) => {
                        return (
                          <SingleStat
                            key={index}
                            stats={stat.stats}
                            color={stat.color}
                            loading={loadingStatsData}
                          />
                        )
                      })
                    }
                  </div>
                </Col>
              </Row>
              <Row className="d-xl-none" style={{ paddingTop: '80px'}}>
                <Col lg={{span: 12}}>
                  <div className="single-stats-containers">
                    {
                      stats.map((stat, index) => {
                        if (index >= (stats.length / 2))
                          return null

                        return (
                          <SingleStat
                            key={index}
                            stats={stat.stats}
                            color={stat.color}
                            loading={loadingStatsData}
                          />
                        )
                      })
                    }
                  </div>
                </Col>
                <Col lg={{span: 12}}>
                  <div className="single-stats-containers">
                    {
                      stats.map((stat, index) => {
                        if (index < (stats.length / 2))
                          return null

                        return (
                          <SingleStat
                            key={index}
                            stats={stat.stats}
                            color={stat.color}
                            loading={loadingStatsData}
                          />
                        )
                      })
                    }
                  </div>
                </Col>
              </Row>

              <Row className="dashboard-charts-container">
                <Col>
                  <Row>
                    <Col>
                      <SectionTitle title="Trials" color="red" />
                    </Col>
                  </Row>
                  <Row>
                    <Col lg={{span: 6}}>
                      <PrismPieChart
                        title="Trial Status"
                        colors="rainbow"
                        chartData={trialStatusPieChartData}
                        loading={loadingTrialsData}
                      />
                    </Col>
                    <Col lg={{span: 6}}>
                      <PrismPieChart
                        colors="rainbow"
                        title="Trial Purpose"
                        chartData={trialPurposePieChartData}
                        loading={loadingTrialsData}
                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col lg={{span: 6}}>
                      <PrismPieChart
                        colors="rainbow"
                        title="Trial Type"
                        chartData={trialTypePieChartData}
                        loading={loadingTrialsData}
                      />
                    </Col>
                    <Col lg={{span: 6}}>
                      <PrismPieChart
                        colors="rainbow"
                        title="Age Groups"
                        chartData={trialAgeGroupsPieChartData}
                        loading={loadingTrialsData}
                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <PrismLineChart
                        colors="rainbow"
                        title="Cumulative Trials Over Time"
                        chartData={cumulativeTrialsLineChartData}
                        xAxisLabel="Year"
                        yAxisLabel="Trials"
                        showLegend={false}
                        loading={loadingTrialsData}
                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <PrismScatterplot
                        title="Landscape"
                        colors="rainbow"
                        chartData={landscapeChartData}
                        xAxisLabel="Trial Start Date"
                        yAxisLabel="Technology as Intervention"
                        loading={loadingLandscapeData}
                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <SectionTitle title="Technology" color="orange" />
                    </Col>
                  </Row>
                  <Row>
                    <Col lg={{span: 6}}>
                      <PrismPieChart
                        colors="rainbow"
                        title="Components"
                        chartData={technologyComponentsPieChartData}
                        loading={loadingTechnologyData}
                      />
                    </Col>
                    <Col lg={{span: 6}}>
                      <PrismPieChart
                        colors="rainbow"
                        title="Body Locations"
                        chartData={bodyLocationsComponentsPieChartData}
                        loading={loadingTechnologyData}
                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col lg={{span: 6}}>
                      <PrismBarChart
                        color="orange"
                        layout="horizontal"
                        title="Top 10 Technologies as Intervention"
                        chartData={top10TechnologiesAsInterventionBarChartData.data}
                        groupKeys={top10TechnologiesAsInterventionBarChartData.group_keys}
                        indexKey="technology"
                        xAxisLabel="Trials"
                        yAxisLabel=""
                        loading={loadingTechnologyData}
                      />
                    </Col>
                    <Col lg={{span: 6}}>
                      <PrismBarChart
                        color="orange"
                        layout="horizontal"
                        title="Top 10 Technologies as Outcomes"
                        chartData={top10TechnologiesAsOutcomesBarChartData.data}
                        groupKeys={top10TechnologiesAsOutcomesBarChartData.group_keys}
                        indexKey="technology"
                        xAxisLabel="Trials"
                        yAxisLabel=""
                        loading={loadingTechnologyData}
                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <PrismBarChart
                        colors="rainbow"
                        title="New Technologies per Year"
                        chartData={newTechnologiesPerYearBarChartData.data}
                        groupKeys={newTechnologiesPerYearBarChartData.group_keys}
                        indexKey="year"
                        xAxisLabel="Year"
                        yAxisLabel="New Technologies"
                        loading={loadingTechnologyData}
                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <SectionTitle title="Conditions" color="yellow" />
                    </Col>
                  </Row>
                  <Row>
                    <Col lg={{span: 6}}>
                      <PrismBarChart
                        color="yellow"
                        layout="horizontal"
                        title="Disease Areas"
                        chartData={conditionsTop10ParentBarChartData.data}
                        groupKeys={conditionsTop10ParentBarChartData.group_keys}
                        indexKey="condition"
                        xAxisLabel="Trials"
                        yAxisLabel=""
                        loading={loadingConditionsData}
                      />
                    </Col>
                    <Col lg={{span: 6}}>
                      <PrismBarChart
                        color="yellow"
                        layout="horizontal"
                        title="Specific Diseases"
                        chartData={conditionsTop10ChildBarChartData.data}
                        groupKeys={conditionsTop10ChildBarChartData.group_keys}
                        indexKey="condition"
                        xAxisLabel="Trials"
                        yAxisLabel=""
                        loading={loadingConditionsData}
                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <PrismSunburst
                        colors="rainbow"
                        title="Conditons Breakdown"
                        chartData={conditionsBreakdownSunburstChartData}
                        loading={loadingConditionsData}
                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <SectionTitle title="Measures" color="green" />
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <PrismBarChart
                        color="green"
                        layout="horizontal"
                        title="Top 10 Measures"
                        chartData={measuresTop10BarChartData.data}
                        groupKeys={measuresTop10BarChartData.group_keys}
                        indexKey="measure"
                        xAxisLabel="Trials"
                        yAxisLabel=""
                        loading={loadingMeasuresData}
                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <PrismLineChart
                        colors="rainbow"
                        title="Measure Use Over Time"
                        chartData={measuresOverTimeLineChart}
                        xAxisLabel="Year"
                        yAxisLabel=""
                        loading={loadingMeasuresData}
                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <SectionTitle title="Manufacturers" color="blue" />
                    </Col>
                  </Row>
                  <Row>
                    <Col lg={{span: 6}}>
                      <PrismBarChart
                        color="blue"
                        layout="horizontal"
                        title="Top 10 Manufacturers By No of Trials"
                        chartData={manufacturersTop10ByTrialsBarChartData.data}
                        groupKeys={manufacturersTop10ByTrialsBarChartData.group_keys}
                        indexKey="manufacturer"
                        xAxisLabel="Trials"
                        yAxisLabel=""
                        loading={loadingManufacturersData}
                      />
                    </Col>
                    <Col lg={{span: 6}}>
                      <PrismBarChart
                        color="blue"
                        layout="horizontal"
                        title="Top 10 Manufacturers by No. of Products"
                        chartData={manufacturersTop10ByProductsBarChartData.data}
                        groupKeys={manufacturersTop10ByProductsBarChartData.group_keys}
                        indexKey="manufacturer"
                        xAxisLabel="Products"
                        yAxisLabel=""
                        loading={loadingManufacturersData}
                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <SectionTitle title="Sponsors" color="indigo" />
                    </Col>
                  </Row>
                  <Row>
                    <Col lg={{span: 6}}>
                      <PrismBarChart
                        color="indigo"
                        layout="horizontal"
                        title="Top 10 Sponsors by Trials"
                        chartData={sponsorsTop10ByTrialsBarChartData.data}
                        groupKeys={sponsorsTop10ByTrialsBarChartData.group_keys}
                        indexKey="sponsor"
                        xAxisLabel="Trials"
                        yAxisLabel=""
                        loading={loadingSponsorsData}
                      />
                    </Col>
                    <Col lg={{span: 6}}>
                      <PrismBarChart
                        color="indigo"
                        layout="horizontal"
                        title="Top 10 Sponsors by Enrollment"
                        chartData={sponsorsTop10ByEnrollmentBarChartData.data}
                        groupKeys={sponsorsTop10ByEnrollmentBarChartData.group_keys}
                        indexKey="sponsor"
                        xAxisLabel="Enrollment"
                        yAxisLabel=""
                        loading={loadingSponsorsData}
                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <PrismSunburst
                        colors="rainbow"
                        title="Sponsors Breakdown"
                        chartData={sponsorsBreakdownChartData}
                        loading={loadingSponsorsData}
                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <SectionTitle title="Geography" color="violet" />
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <PrismChoropleth
                        colors="rainbow"
                        title="Site Volume"
                        chartData={geographyFacilitiesChartData}
                        loading={loadingGeographyData}
                      />
                    </Col>
                  </Row>
                </Col>
              </Row>
          </div>
        </div>

        { activeCategoryFilter &&
          <SlidingPane
            isOpen={sidebarIsVisible}
            from={'left'}
            hideHeader={true}
            width={showDoubleSideBar ? '750px' : '500px'}
            onRequestClose={() => closeSidebar()}
          >
            <div className={"sliding-pane-container " + colors[activeCategoryFilter]}>
              <div className="left-pane">
                <SearchFilters
                  activeCategory={activeCategoryFilter}
                  activeFilter={activeParentFilter}
                  sections={activeParentFilterSections}
                  onFilterClicked={onParentFilterClicked}
                  onFilterLabelClicked={onParentFilterLabelClicked}
                  onFilterHover={onFilterHover}
                  onFilterUnHover={onFilterUnHover}
                />
              </div>
              {
                showDoubleSideBar &&
                <div className="right-pane">
                  <SearchFilters
                    activeCategory={activeCategoryFilter}
                    sections={activeChildFilterSections}
                    onFilterClicked={onChildFilterClicked}
                    onFilterLabelClicked={onChildFilterClicked}
                  />
                </div>
              }
            </div>
          </SlidingPane>
        }
      </Container>
    </div>
  )
}


export default withRouter(DashboardRoute);
